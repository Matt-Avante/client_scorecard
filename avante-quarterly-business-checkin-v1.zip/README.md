# Avante Quarterly Business Check-in

GitHub Pages-ready client check-in site.

## Upload to GitHub

Upload the contents of this folder to the root of the existing `client_scorecard` repository. Replace the current `index.html` and add the other files and folders.

Required public site files:

- `index.html`
- `styles.css`
- `app.js`
- `config.js`
- `assets/avante-logo.webp`

The `docs` folder and `google-apps-script.js` are support files. They do not affect the public page.

## Collect responses in Google Sheets

1. Upload `docs/Avante_Quarterly_Business_Checkin_Responses.xlsx` to Google Drive.
2. Open it using Google Sheets.
3. Select **Extensions > Apps Script**.
4. Paste in `google-apps-script.js`.
5. Deploy it as a Web app, executing as yourself and allowing access to anyone.
6. Copy the Web app URL.
7. Open `config.js` in GitHub and paste the URL into `responseEndpoint`.
8. Commit the change.

## Tally

The field names used in the website are documented in the workbook's **Field Map** tab. Use those names when mapping a Tally form into Google Sheets through Tally, Make or Zapier.

## Live URL

Your current GitHub Pages URL remains:

`https://matt-avante.github.io/client_scorecard/`
